<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="scripts/extjs/resources/css/ext-all.css">
    <script type="text/javascript" src="scripts/extjs/ext-all.js"></script>
    <script type="text/javascript" src="scripts/login/app/app.js"></script>
</head>
<body>
    <br/>
    <br/>
    <br/>
    <br/>
    <center>
        <img src="images/ranchmarket.jpg"/>
    </center>
</body>
</html>