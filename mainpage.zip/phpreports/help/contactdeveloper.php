<html>
	<body>
		<p style='width:400px;height:200px;background-color:#F5F5F5;border-style:solid;border-width:2;border-color:#CCCCCC;padding:10px 10px 10px 10px;font-family:verdana,arial,helvetica,sans-serif;color:#505050;font-size:12px;'>";
		<span style='font-size:18px;color:#FF0000;font-weight:bold;'><?php print $_GET["msg"]; ?></span><br/><br/>
		This is an error that is kind of rare (thanks Lord!). Seems that something inside the code is not working well,
		and when I say that is rare is <b>not</b> because the code is perfect but some stuff will not be running well if this
		happens often. :-)<br/>
		<br/>
		Please send a message on the <b>PHPReports</b> web site forum:<br/>
		<br/>
		<a href="https://sourceforge.net/forum/forum.php?forum_id=186814">https://sourceforge.net/forum/forum.php?forum_id=186814</a><br/>
		<br/>
		Thank you.
		<br clear='all'/>
		</p>
	</body>
</html>	
