<html>
	<body>
		<p style='width:400px;height:200px;background-color:#F5F5F5;border-style:solid;border-width:2;border-color:#CCCCCC;padding:10px 10px 10px 10px;font-family:verdana,arial,helvetica,sans-serif;color:#505050;font-size:12px;'>";
		<span style='font-size:18px;color:#FF0000;font-weight:bold;'>CONNECTION REFUSED</span><br/><br/>
		The database specified by you refused your connection.<br/>
		<br/>
		I mean, it does not recognize the <b>user name</b>, the <b>password</b> and some other parameter you're trying
		to use there.<br/>
		<br/>
		Please make a PHP code file and try to connect to your database. If it works, please check the database interface
		file on <b>&lt;PHPReports_dir&gt;/database/db_&lt;your_database_name_here&gt;.php</b> to see if you find something weird. If
		you find, please contact me on the <b>PHPReports</b> website and I'll be glad to help you to fix it.<br/>
		<br clear='all'/>
		</p>
	</body>
</html>	
