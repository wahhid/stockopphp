<html>
	<body>
		<p style='width:400px;height:200px;background-color:#F5F5F5;border-style:solid;border-width:2;border-color:#CCCCCC;padding:10px 10px 10px 10px;font-family:verdana,arial,helvetica,sans-serif;color:#505050;font-size:12px;'>";
		<span style='font-size:18px;color:#FF0000;font-weight:bold;'>NO COLUMNS RETURNED FROM YOUR QUERY</span><br/><br/>
		Are you sure there is some valid columns in your query?<br/>
		<br/>
		What happened here is that I asked the database about the information you asked me, but the database said 
		"hey dude, there is nothing like that here, I didn't find the fields you asked for".<br/>
		<br/>
		So there is nothing to work with there in your query. Please run it on some database tool to make sure it is ok
		before sending it to <b>PHPReports</b>.
		<br clear='all'/>
		</p>
	</body>
</html>	
