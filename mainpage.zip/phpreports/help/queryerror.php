<html>
	<body>
		<p style='width:400px;height:200px;background-color:#F5F5F5;border-style:solid;border-width:2;border-color:#CCCCCC;padding:10px 10px 10px 10px;font-family:verdana,arial,helvetica,sans-serif;color:#505050;font-size:12px;'>";
		<span style='font-size:18px;color:#FF0000;font-weight:bold;'>QUERY ERROR</span><br/><br/>
		I was connected on your database but there was some kind of error when running the SQL query.<br/>
		<br/>
		Please check if it is a valid query using some database interface program, and then return here again.
		<br clear='all'/>
		</p>
	</body>
</html>	
