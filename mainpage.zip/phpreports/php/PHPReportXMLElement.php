<?php
	// will change this to an interface on PHP5
	class PHPReportXMLElement {
		function getXMLOpen() {
			return "<ELEMENT>";
		}
		function getXMLClose() {
			return "</ELEMENT>";
		}
	}
?>
