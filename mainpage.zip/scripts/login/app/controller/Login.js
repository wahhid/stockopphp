Ext.define('App.controller.Login', {
    extend: 'Ext.app.Controller',    
    init: function() {
        
    }                                
});