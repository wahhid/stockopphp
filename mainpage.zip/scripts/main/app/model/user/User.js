Ext.define('App.model.user.User',{
    extend: 'Ext.data.Model',
    fields:['username','fullname','password','usertype']
})